# opelR #

This package contains a handful of functions that I find myself regularly needing.

### Who do I talk to? ###

* Ryan (@opelr)
